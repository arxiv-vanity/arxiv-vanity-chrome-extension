## Chrome-Arxiv-Vanity

An extension that provides an [Arxiv Vanity](https://www.arxiv-vanity.com) link directly on an accessed arxiv paper page.

## Installation and Usage

Navigate to the [chrome web store](https://chrome.google.com/webstore/detail/arxiv-vanity-plugin/jfnlkegibnoaagfdabjkchhocdhnoofk) and install the extension. Then when you browse to any [arxiv.org](arxiv.org) paper, click the "Arxiv Vanity" link the the downloads section.
