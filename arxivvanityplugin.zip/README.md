# Chrome-Arxiv-Vanity

An extension that provides an [Arxiv Vanity](https://www.arxiv-vanity.com) link directly on an accessed arxiv page.

# Installation (unofficial)

1. Clone this repo.
2. Open the [chrome://extensions](chrome://extensions) page.
3. Check the *Developer Mode* box on the top of the page.
4. Click "Load unpacked extension..." and select the repo folder.

# Usage

Navigate to any [arxiv.org][arxiv] paper, click the "Arxiv Vanity" link the the downloads section.
